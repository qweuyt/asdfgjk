# ChottaChetanTalkies
Index Your Favourite Tv Channels & Enjoy Live Tv Over Internet

# Edit
- add custom title (home.html & watch.html)
- add custom favicon (home.html & watch.html)
- add custom img or gif
- add m3u8 file in watch.html
- you can add watch.html as you wanted just link them to buttons in home.html
- change repo url to your repo url (in README.md) in heroku button and deploy.

<br>
<p align="center">
<a href = "https://heroku.com/deploy?template=https://github.com/dishapatel010/ChottaChetanTalkies/tree/master"><img src="https://www.herokucdn.com/deploy/button.svg" alt="hmm" width="250px"></a></p>
<br>

# ToDo

- player fix
- code revisit
- add live demo

# WARNING !!

- do not touch index.php
- do not touch CORS.php(it's just experiment)
<div align="center">
<img src='https://i.imgur.com/o87rrcC.jpg' alt="Touch Kaise Kiya!"/>
</div>


# You Can Contact Me On Telegram as 
- @midnightmadwalk

# credits:
- Clapr devs.
- medium
